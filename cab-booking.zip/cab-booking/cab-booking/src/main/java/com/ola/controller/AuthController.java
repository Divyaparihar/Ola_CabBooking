package com.ola.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ola.config.JwtUtil;
import com.ola.domain.UserRole;
import com.ola.exception.UserException;
import com.ola.modal.Driver;
import com.ola.repository.DriverRepository;
import com.ola.repository.UserRepository;
import com.ola.request.DriverSignupRequest;
import com.ola.request.LoginRequest;
import com.ola.request.SignupRequest;
import com.ola.response.JwtResponse;
import com.ola.service.CustomUserDetailsService;
import com.ola.service.DriverService;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private DriverRepository driverRepository;
	
	@Autowired
	private DriverService driverService;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	@Autowired
	private CustomUserDetailsService customUserDetailsService;
	
	@Autowired
	private JwtUtil jwtUtil;
	
	public AuthController(UserRepository userRepository, 
			DriverRepository driverRepository,
			PasswordEncoder passwordEncoder, 
			JwtUtil jwtUtil,
			CustomUserDetailsService customUserDetailsService,
			DriverService driverService) {
		this.userRepository =userRepository;
		this.driverRepository = driverRepository;
		this.passwordEncoder = passwordEncoder;
		this.jwtUtil = jwtUtil;
		this.customUserDetailsService = customUserDetailsService;
	    this.driverService = driverService;
	}
	
	@PostMapping("/user/signup")
    public ResponseEntity<JwtResponse> signupHandler(@RequestBody SignupRequest signupRequest)
            throws UserException, AuthenticationException {
        
        User user = userRepository.findByEmail(signupRequest.getEmail());
        JwtResponse jwtResponse = new JwtResponse();
        
        if (user != null) {
            throw new UserException("User Already Exists With Email " + signupRequest.getEmail());
        }
        
        String encodedPassword = passwordEncoder.encode(signupRequest.getPassword());
        
        User createdUser = new User();
        createdUser.setEmail(signupRequest.getEmail());
        createdUser.setPassword(encodedPassword);
        createdUser.setFullName(signupRequest.getFullName());
        createdUser.setMobile(signupRequest.getMobile());
        createdUser.setRole(UserRole.USER);
        
        User savedUser = userRepository.save(createdUser);
        
        Authentication authentication = new UsernamePasswordAuthenticationToken(
            savedUser.getEmail(), savedUser.getPassword());
        SecurityContextHolder.getContext().setAuthentication(authentication);
        
        String jwt = jwtUtil.generateJwtToken(authentication);
        
        jwtResponse.setJwt(jwt);
        jwtResponse.setAuthenticated(true);
        jwtResponse.setError(false);
        jwtResponse.setErrorDetails(null);
        jwtResponse.setType(UserRole.USER);
        jwtResponse.setMessage("Account Created Successfully: " + savedUser.getFullName());
        
        return new ResponseEntity<JwtResponse>(jwtResponse, HttpStatus.ACCEPTED);
    }
	
	
	//api/auth/driver/sign
	@PostMapping("/driver/signup")
	public ResponseEntity<JwtResponse> driverSignupHandler(@RequestBody DriverSignupRequest driverSignupRequest){
			
			Driver driver = driverRepository.findByEmail(driverSignupRequest.getEmail());
			
			JwtResponse jwtResponse=new JwtResponse();
				
			if(driver!=null) {
				
				jwtResponse.setAuthenticated(false);
			    jwtResponse.setErrorDetails("email already used with another account");
			    jwtResponse.setError(true);
			        
				return new ResponseEntity<JwtResponse>(jwtResponse,HttpStatus.BAD_REQUEST);
			}
			
			
			Driver createdDriver=driverService.registerDriver(driverSignupRequest);
			
			Authentication authentication = new UsernamePasswordAuthenticationToken(createdDriver.getEmail(), createdDriver.getPassword());
	        SecurityContextHolder.getContext().setAuthentication(authentication);
	        
			String jwt = jwtUtil.generateJwtToken(authentication);
	        
	        jwtResponse.setJwt(jwt);
	        jwtResponse.setAuthenticated(true);
	        jwtResponse.setError(false);
	        jwtResponse.setErrorDetails(null);
	        jwtResponse.setType(UserRole.DRIVER);
	        jwtResponse.setMessage("Account Created Successfully: "+createdDriver.getName());
	        
	        
			return new ResponseEntity<JwtResponse>(jwtResponse,HttpStatus.ACCEPTED);
		}
	
	
	//api/auth/signin
	@PostMapping("/Signin")	
	public ResponseEntity<JwtResponse> signin(@RequestBody LoginRequest req) {
        String username = req.getEmail();
        String password = req.getPassword();
        
        Authentication authentication = authenticate(password, username);
	
        SecurityContextHolder.getContext().setAuthentication(authentication);
        
        // Generate JWT token
        String jwt = jwtUtil.generateJwtToken(authentication);
        
        JwtResponse jwtResponse = new JwtResponse();
        jwtResponse.setJwt(jwt);
        jwtResponse.setAuthenticated(true);
        jwtResponse.setError(false);
        jwtResponse.setErrorDetails(null);
        jwtResponse.setType(UserRole.USER);
        jwtResponse.setMessage("Account Login Successfully");
        
        return new ResponseEntity<JwtResponse>(jwtResponse,
        		HttpStatus.ACCEPTED);
	
	}
	
	private Authentication authenticate(String password, String username) {
		UserDetails userDetails = customUserDetailsService.loadUserByUsername(username);
	   
		 if (userDetails == null) {
	        	System.out.println("sign in userDetails - null " + userDetails);
	            throw new BadCredentialsException("Invalid username or password");
	        }
	        if (!passwordEncoder.matches(password, userDetails.getPassword())) {
	        	System.out.println("sign in userDetails - password not match " + userDetails);
	            throw new BadCredentialsException("Invalid username or password");
	        }
	        return new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());	
}
	
}	



