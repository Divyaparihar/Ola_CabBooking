package com.ola.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ola.config.JwtUtil;
import com.ola.repository.DriverRepository;
import com.ola.repository.UserRepository;
import com.ola.response.MessageResponse;

@RestController
public class HomeController {
	
	@Autowired
	private JwtUtil jwtUtil;
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private DriverRepository driverRepository;
	
	@GetMapping("/")
	public ResponseEntity<MessageResponse> homeController(){
		MessageResponse msg=new MessageResponse("welcome to Ola Backend System");
		
		return new ResponseEntity<MessageResponse>(msg,HttpStatus.ACCEPTED);
		
	}

}
