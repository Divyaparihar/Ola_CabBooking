package com.ola.service;

import java.util.List;

import com.ola.exception.DriverException;
import com.ola.modal.Driver;
import com.ola.modal.Ride;
import com.ola.request.DriverSignupRequest;

public interface DriverService {

public Driver registerDriver(DriverSignupRequest driverSignupRequest);
	
	public List<Driver> getAvailableDrivers(double pickupLatitude,
			double picupLongitude, Ride ride);
	
	public Driver findNearestDriver(List<Driver> availableDrivers, 
			double picupLatitude, double picupLongitude);
	
	public Driver getReqDriverProfile(String jwt) throws DriverException;
	
	public Ride getDriversCurrentRide(Integer driverId) throws DriverException;
	
	public List<Ride> getAllocatedRides(Integer driverId) throws DriverException;
	
	public Driver findDriverById(Integer driverId) throws DriverException;
	
	public List<Ride> completedRids(Integer driverId) throws DriverException;
	
}
	

