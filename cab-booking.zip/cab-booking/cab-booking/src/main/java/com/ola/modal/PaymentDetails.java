package com.ola.modal;

import com.ola.domain.PaymentStatus;

public class PaymentDetails {

	private PaymentStatus paymentStatus;
	private String paymentId;
	private String razorpayPaymentLinkId;
	private String razorpayPaymentLinkReferenceId;
	private String razorpayPaymentLinkStatus;
	private String razorpayPaymentId​;
	
}
