package com.ola.config;

public class JwtSecurityContext {

	public static final String JWT_KEY="afnadncxhyuasj948927u4bjy78642547kjansdfbauegtrrry";
	public static final String JWT_HEADER="Authorization";
	
}
