package com.ola.domain;

public enum RideStatus {

	REQUESTED,
	ACCEPTED,
	STARTED,
	COMPLETED,
	CANCELLED
	
}
