package com.ola.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ola.modal.License;


public interface LicenseRepository extends JpaRepository<License, Integer> {

}
