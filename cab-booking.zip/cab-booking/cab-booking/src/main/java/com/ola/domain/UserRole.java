package com.ola.domain;

public enum UserRole {

	DRIVER,
	USER
	
}
