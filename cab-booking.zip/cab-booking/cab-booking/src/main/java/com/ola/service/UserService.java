package com.ola.service;

import java.util.List;

import com.ola.exception.UserException;
import com.ola.modal.Ride;
import com.ola.modal.User;

public interface UserService {
	
//	public User createUser(User user) throws UserException;
	
	public User getReqUserProfile(String token) throws UserException;
	
	public User findUserById(Integer Id) throws UserException;
	
//	public User findUserByEmail(String email) throws UserException;
	
	public List<Ride> completedRids(Integer userId) throws UserException;
	

}


