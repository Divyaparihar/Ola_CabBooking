package com.ola.service;

import com.ola.exception.DriverException;
import com.ola.exception.RideException;
import com.ola.modal.Driver;
import com.ola.modal.Ride;
import com.ola.modal.User;
import com.ola.request.RideResquest;

public interface RideService {

	public Ride requestRide(RideResquest rideResquest, User user) throws DriverException;
	
	public Ride createRideRequest(User user, Driver nearesDriver,
			double picupLatitude,double pickupLongitude,
			double destinationLatitude,double destinationLongitude,
			String pickupArea,String destinationArea);
	
	public void acceptRide(Integer rideId) throws RideException;
	
	public void declineRide(Integer rideId, Integer driverId) throws RideException;
	
	public void startRide(Integer rideId,int opt) throws RideException;
	
	public void completeRide(Integer rideId) throws RideException;
	
	public void cancelRide(Integer rideId) throws RideException;
	
	public Ride findRideById(Integer rideId) throws RideException;

}

