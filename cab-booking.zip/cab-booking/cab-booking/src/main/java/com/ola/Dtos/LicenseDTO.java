package com.ola.Dtos;

public class LicenseDTO {

	private String number;
    private String expiryDate;
    
}
