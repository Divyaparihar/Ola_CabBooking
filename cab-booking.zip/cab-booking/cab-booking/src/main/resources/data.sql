DROP TABLE IF EXISTS Driver;
DROP TABLE IF EXISTS License;

CREATE TABLE `driver` (
`id` int AUTO_INCREMENT PRIMARY KEY,
`name` varchar(100) NOT NULL,
`email` varchar(100) NOT NULL,
`mobile` varchar(13) NOT NULL,
`rating` float NOT NULL,
`latitude` float(15) NOT NULL,
`longitude` float(15) NOT NULL,
`role` varchar(15)NOT NULL
);

CREATE TABLE `License` (
`id` int AUTO_INCREMENT PRIMARY KEY,
`licensenumber` int(10) NOT NULL,
`licenseState` varchar(100) NOT NULL,
`licenseExpirationDate` date DEFAULT NULL
);

CREATE TABLE Ride (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    driver_id INT,
    declinedDrivers VARCHAR(255),
    pickupLatitude DOUBLE,
    pickupLongitude DOUBLE,
    destinationLatitude DOUBLE,
    destinationLongitude DOUBLE,
    pickupArea VARCHAR(255),
    destinationArea VARCHAR(255),
    distance DOUBLE,
    duration BIGINT,
    status VARCHAR(50),
    startTime DATETIME,
    endTime DATETIME,
    fare DOUBLE,
    otp INT
);

CREATE TABLE User (
    id INT PRIMARY KEY AUTO_INCREMENT,
    fullName VARCHAR(255) UNIQUE,
    email VARCHAR(255),
    mobile VARCHAR(20) UNIQUE,
    password VARCHAR(255),
    profilePicture VARCHAR(255),
    role VARCHAR(50)
);

CREATE TABLE Vehicle (
    id INT PRIMARY KEY AUTO_INCREMENT,
    make VARCHAR(255),
    model VARCHAR(255),
    year INT,
    color VARCHAR(255),
    license_plate VARCHAR(20),
    capacity INT,
    driver_id INT,
    FOREIGN KEY (driver_id) REFERENCES Driver(id)
);



INSERT INTO `driver` (`id`, `name`, `email`, `mobile`, `rating`, `latitude`, `longitude`, `role`)
VALUES ('121','Jayraj','jayraj123@gmail.com', '5489557832', '4.5', '78.3', '56.7', 'user');

INSERT INTO `License` (`id`, `licensenumber`, `licenseState`, `licenseExpirationDate`)
VALUES ('1', '85147', 'Rajasthan', '2021-01-01');

INSERT INTO Ride (
    user_id, driver_id, declinedDrivers, pickupLatitude, pickupLongitude,
    destinationLatitude, destinationLongitude, pickupArea, destinationArea,
    distance, duration, status, startTime, endTime, fare, otp
)
VALUES (
    1, 2, '3,4,5', 37.12345, -122.6789, 37.54321, -122.9876,
    'Pickup Area A', 'Destination Area B', 10.5, 1800,
    'Completed', '2023-08-25 10:00:00', '2023-08-25 10:30:00', 25.75, 1234
);

INSERT INTO User (fullName, email, mobile, password, profilePicture, role)
VALUES ('John Doe', 'john@example.com', '1234567890', 'hashed_password', 'profile.jpg', 'USER');

